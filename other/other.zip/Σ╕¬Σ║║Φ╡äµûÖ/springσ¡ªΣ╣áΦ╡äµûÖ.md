# 1 spring bean的生命周期
   1. 如果是单例模式,当容器启动的时候，对象会被创建，一直直到容器死亡，对象才会被销毁
   2. 如果是多例模式，当对象被使用的时候才会被创建，只要对象不使用的时候，对象就会被垃圾回收，多例模式spring只负责创建bean，不负责销毁
   
# 2 spring applicantContext refresh过程
 1.  prepareRefresh();  // 刷新前的准备操作 
 2.  obtainFreshBeanFactory(); //获取beanFactory,默认DefaultListableBeanFactory
 3.  prepareBeanFactory(beanFactory); //beanFactory 的一些前置工作
 4.  postProcessBeanFactory(beanFactory);// BeanFactory准备⼯作完成后进⾏的后置处理⼯作
 5.  invokeBeanFactoryPostProcessors(beanFactory);// 实例化并调⽤实现了BeanFactoryPostProcessor接⼝的Bean,实现前置跟后置操作
 6.  registerBeanPostProcessors(beanFactory);// 注册BeanPostProcessor
 7.  initMessageSource(); // 国际化的操作
 8.  initApplicationEventMulticaster(); 初始化事件派发器
 9.  onRefresh(); //⼦类重写这个⽅法，在容器刷新的时候可以⾃定义逻辑
 10. registerListeners(); // 注册应⽤的监听器。就是注册实现了ApplicationListener接⼝的监听器bean
 11. finishBeanFactoryInitialization(beanFactory); 
    // 初始化所有剩下的⾮懒加载的单例bean
    初始化创建⾮懒加载⽅式的单例Bean实例（未设置属性）
    填充属性
    初始化⽅法调⽤（⽐如调⽤afterPropertiesSet⽅法、init-method⽅法）
    调⽤BeanPostProcessor（后置处理器）对实例bean进⾏后置处
12. finishRefresh(); //完成context的刷新。主要是调⽤LifecycleProcessor的onRefresh()⽅法，并且发布事件（ContextRefreshedEvent）

