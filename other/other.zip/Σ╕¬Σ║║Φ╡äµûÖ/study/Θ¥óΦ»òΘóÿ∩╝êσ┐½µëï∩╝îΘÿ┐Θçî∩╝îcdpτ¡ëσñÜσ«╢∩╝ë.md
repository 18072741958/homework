# CDP面试题

1.SpringBoot启动过程

2.SpringBoot加载指定位置JAR包

3.SpringBoot tomcat启动过程

4.Sentinel降级后恢复原理

5.时间滑动窗口限流原理

6.线程池核心线程数设置的多少

7.你知道Java中有哪些锁

8.Lock实现原理

9.非公平锁与公平锁实现区别

10.死锁

11.数据库死锁

12.MySql在RR隔离级别下什么时候会发生幻读

13.QPS,TPS,吞吐量

14.Oauth2四种模式

15.dubbo与fegin的比较

16.分布式锁

17.单例为什么要双重检查锁

18.DDD与MVC的区别

19.多表联合查询与业务层里面进行逻辑拼接的优劣

# Strikingly面试题:

1.为什么选择分布式微服务而不是单体集群

2.为什么使用SpringCloud

3.选择SpringCloud后有没有后悔使用了哪些组件

4.假设某市举行选美大赛,候选人有100位,该市有800万人口,根据往年经验,约有30%~40%的人参与投票,每人只能投一票,投票时间为24小时,这个系统你怎么设计

5.假设投票高峰期在投票开始的前15-20分钟,这个时候你怎么设计

6.假设选美大赛升级为全球活动,会有60亿人参与,此时系统需要怎么设计

# 阿里巴巴

1.HashMap插入的过程

2.HashMap为什么使用尾插法

3.Hash冲突有什么解决方式

4.JVM内存布局

5.常量池在JVM哪里

6.volatile实现原理

7.你用过什么设计模式

8.你用到哪些设计思想

# 涂鸦智能

1.dubbo服务注册过程

2.Spring bean

3.SpringBoot自动装配

4.nacos与zookeeper的区别

5.JVM内存布局

6.类加载机制

7.JVM调优

8.读写锁实现

9.分布式锁

# 快手

1.写SQL语句分析索引

2.使用SQL语句实现指定的功能

3.Redis底层数据结构

4.RabbitMq事务

5.MVVC底层数据结构

6.一致性hash

7.JVM内存结构

8.JVM调优

# MOKA

1.JVM调优

2.JVM排查问题

3.synchronized

4.Lock

5.AQS其他实现

6.并发容器

7.CurrentHashMap实现

8.创建线程

9.线程池构造器参数

10.ThreadLocal

11.双亲委派机制

12.Spring FactoryBean

13.innodb聚簇非聚簇索引

14.MVVC底层实现

15.数据库死锁

16.Redis底层数据结构

17.Redis持久化

18.Linux awk与grep命令