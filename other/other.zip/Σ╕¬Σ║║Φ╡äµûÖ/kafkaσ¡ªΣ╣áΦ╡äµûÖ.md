# 1 kafka的基本架构
 1. Producer 概念
    1. 默认通过轮询把消息均匀的分布在所有分区上
    2. 通过消息键跟分区器，分区器会生成一个散列值，将其映射到指定的分区，这样能保证同一个键的消息会被指定同一个分区上
    3. 自定义实现分区器，根据不同的业务规则来映射分区
 2. Consumer 概念
    1. 消费者会按照消息的生成顺序来进行消费 （如何做到的？）
    2. 消费者根据消息的偏移量来区分已经读过的消息，偏移量是一个不断递增的整数值，在每个分区都是唯一的，最后的消息偏移量维护在kafka中，下次启动的时候能保障读取状态不会变
    3. 群组保障每个分区只能被一个消费者使用
# 2 生产者
 3. producer生产者 配置项
    1. acks： 默认是all，代表消息会等待所有的副本分区确认记录，这是最高级别的可靠性保障
            ack = 1，代表消息只收到主分区的确认，不等副本分区的确认就认为消息已经完成发送，这时候如果主分区宕机可能会丢失数据
            ack = 0，代表消息只发送到缓冲区没等主分区的确认就认为消息已经发送完成，该情形不能保证broker已经收到消息，所以retire参数也不生效
    2. retires 消息发送失败的重试次数，如果要保证消息的顺序性，那么需要设置MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION=1
    3. compression.type 默认是none，可以选择gzip，已zip形式进行压缩然后发送到broke
    4. partitioner.class 设置自定义的分区器，让消息按照一定的逻辑发送到特定逻辑的分区
    5. batch.size 本地消息的缓存池大小，设置一定大小的缓存池大小，有助于吞吐量
 4. producer创建消息的流程 
    1. Producer创建时，会创建一个Sender线程并设置为守护线程。
    2. 生产消息时，内部其实是异步流程；生产的消息先经过拦截器->序列化器->分区器，然后将消
    息缓存在缓冲区（该缓冲区也是在Producer创建时创建）。
    1. 批次发送的条件为：缓冲区数据大小达到batch.size或者linger.ms达到上限，哪个先达到就算
    哪个。
    1. 批次发送后，发往指定分区，然后落盘到broker；如果生产者配置了retrires参数大于0并且失
    败原因允许重试，那么客户端内部会对该消息进行重试。
    1. 落盘到broker成功，返回生产元数据给生产者。
    2. 元数据返回有两种方式：一种是通过阻塞直接返回，另一种是通过回调返回。
 5. producer 序列化器
    1. 可以自定义实现Serializer序列号接口
 6. producer 分区器
    1. ProducerRecord的结构为 topic partition key value,
    2. 如果partition不为空，则记录发送到partition的分区
    3. 如果partition为空，key不为空，则取hash(key)的值的分区
    4. 如果partition为空，key也为空，那么就会用轮询的方式发送到每个分区
 7.  producer 拦截器
     1. Interceptor使得用户在消息发送前以及Producer回调逻辑前有机会对消息做一些定制化需求，比如修改消息等。同时，Producer允许用户指定多个Interceptor按序作用于同一条消息从而形成一个拦截链(interceptor chain)
     2. onSend(ProducerRecord)：在消息被序列化以计算分区前调用该方法
     3. onAcknowledgement(RecordMetadata, Exception)：该方法会在消息被应答之前或消息发送失败时调用，并且通常都是在Producer回调逻辑触发之前
 8. producer 线程模型
   1.  producer分为主线程跟sender线程
   2.  主线程主要是做消息的创建，拦截器过滤，序列化，分区器处理，然后把消息追加到本地的消息收集器，消息收集器为一个队列形式的缓存池<分区号,数待发送的消息>，如果加入的消息超过batch.size大小，则会发送
   3.  sender线程  主要是从缓存池中去获取消息进行发送

# 3 消费者
 1. consumer消费者 配置项
   1. enable.auto.commit=true 消费者会自动提交自己的位移量到broker
   2. auto.commit.interval.ms 消费者每隔多久将消息提交到服务器 
   3. session.timout.ms 收到心跳如果未回复的超时时间 一般设置为6s
   4. heartbeat.interval.ms 心跳的发送频率 一般设置为2s
   5. max.poll.interval.ms poll拉取数据的间隔时间 一般设置为5分钟
   6. auto.offset.reset 如果当服务器中的偏移量不存在的时候
      1. earliest 自动重置到最早的偏移量
      2. latest 自动重置到最新的偏移量
      3. none 如果没找到以前的偏移量 就抛出异常
 2. 位移提交
    1. 自动提交位移
         Kafka会保证在开始调用poll方法时，提交上次poll返回的所有消息，因此自动提交不会出现消息丢失，但会重复消费，重复消费举例
         Consumer 每 5s 提交 offset，假设提交 offset 后的 3s 发生了 Rebalance，Rebalance 之后的所有 Consumer 从上一次提交的 offset 处继续消费，因此 Rebalance 发生前 3s 的消息会被重复消费
    2. 异步提交位移
         通过代码手动提交位移

# 3 分区
 1. 副本
    1. kafka为了保障高可用，副本分为leader副本跟flower副本
    2. 当副本宕机重启
       1. 少部分副本宕机重启
          当leader宕机了，会从follower选择一个作为leader。当宕机的重新恢复时，会把之前commit的数据清空，重新从leader里pull数据
       2. 全部副本宕机
          1、等待ISR中的一个恢复后，并选它作为leader。（等待时间较长，降低可用性）2、选择第一个恢复的副本作为新的leader，无论是否在ISR中。（并未包含之前leader commit的数据，因此造成数据丢失）  
   3. 分区分配策略
      1. RangeAssignor 会按照订阅者的名称进行排序，尽可能的平均分配给消费者，是kafka默认的分区分配策略
      2. RoundRobinAssignor 会按照订阅者的名称随机进行分配
      3. StickyAssignor 按照一定的算法，尽可能的保持平均进行分配，然后会尽量保证分配结果与上次的结果相似
      4. PartitionAssigno 自定义实现分区算法实现接口
   4. 如何选举？ 为什么不用少数服从多数的算法？
      1. 通过zk维护一个isr列表，isr指的是有正常消息同步的副本，osr指的是可能失效的副本，两者合成为ar集合
      2. 通过isr的形式，冗余度比较低，只要保证有一个可以用的副本就可以成为leader了，但如果是选举算法，那就必须要超过半数的节点选举通过才能成为leader

# 物理存储
 1. 页缓存技术
  操作系统本身有一层缓存叫page cache，这是内存中的一种缓存，就是操作系统自带的缓存，kafka每次写入都是先写到page cache中，然后由os来决定什么时候写入磁盘
 2. 磁盘顺序写
  磁盘顺序写避开了磁盘指针寻址过程，顺序写的速度相当于写内存，速度非常快
 3. 零拷贝技术
  消费者在从broker中拉取数据的时候，正常的数据请求路径是 磁盘 ----> page cache --拷贝到--> 应用程序 -- 拷贝到-> socket缓存 ---> 网卡 ----> 消费者，这个过程涉及到了两次数据拷贝过程，kafka采用的是 磁盘----> pagecache  --拷贝描述符--> socket缓存 ，然后有page cache直接读取数据发送到网卡然后发送给网卡，这就实现了零拷贝

# rebalance
  什么时候触发再平衡？ 当消费组有新增或者退出消费者，或者分区有新增或者删除的时候会触发再平衡
  再平衡过程:
  1. 通过kafka协调者来协调器(coordinator),当消费组中的消费者第一个启动的时候，会跟kafka broker确认谁是协调器，通过确定consumer offset这个topic的哪个分区，即这个topic是由位置管理topic的哪个分区来支持就由对应的broker作为协调器 算法为（groupId的hashcode）% 分区数 
  2. 所有的成员像协调器发送一个join请求，等到所有的消费者发送完join请求后，协调器会从中选取一个leader，并将组员信息跟订阅信息发送给leader，由leader完成分配方案后，会将分配信息通过sync请求发送给协调器，同时所有组内所有的follower也会发送一个空sync请求，协调者收到结果后，会通过sync请求返回给消费者
  3. 如何减少再平衡？1.session.timout.ms 心跳参数，如果太小，系统会默认你离线 2.heartbeat.interval.ms 发送心跳的频率，越高的话越不容易被误判  3.max.poll.interval.ms 处理一批次的时间，越小容易被误判
  4. 再平衡的分区算法：
  1.RangeAssignor 按照消费者总数和分区总数尽可能平均的分配，先会按照消费者的字母id排序，多的会分配给字母id靠前的消费者 如果多个topic的情况下都出现这种情况，会出现分配越来越不公平 2.RoundRobinAssignor  不像range从单个topic触发，而是从所有topic列表的角度出发，来尽可能的保持分配均匀
  3.StickyAssignor 分区尽可能的平衡，然后跟上一次尽可能保持一致

# 如何保持顺序消费
1. 自定义一个分区器，让主键id%分区数，这样能保证相同一个数据的bin log是发到同一个分区上的
2. 设置max.in.flight.requests.per.connection=1 ，因为一个batch 在发送失败的时候，会尝试重试重新发送，如果这个时候多个batch都在尝试重新发送的话，有可能导致顺序不一致
   max.in.flight.requests.per.connection 能保证当前未确认的分区发送只有一个

# 如何解决重复消费问题
1. enable.idempotence=true 他会为每条消息分配一个id，能保证数据的唯一性
2. rebalance 之后没有自动commit，但是已经消费一部分数据了，从上次的提交位置消费，会出现重复消费  需要业务做幂等   

